package com.restaurant.service;

import com.restaurant.model.FoodItem;
import com.restaurant.repository.FoodRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FoodService {
    private final FoodRepository foodRepository;

    public FoodService(FoodRepository foodRepository) {
        this.foodRepository = foodRepository;
    }

    public List<FoodItem> getAllFoodItems() {
        return foodRepository.findAll();
    }

    public FoodItem getFoodItemById(int id) {
        return foodRepository.findById(id).orElse(null);
    }

    public FoodItem addFoodItem(FoodItem foodItem) {
        return foodRepository.save(foodItem);
    }

    public FoodItem updateFoodItem(int id, FoodItem foodDetails) {
        FoodItem existingFoodItem = foodRepository.findById(id).orElse(null);
        if (existingFoodItem != null) {
            existingFoodItem.setName(foodDetails.getName());  // ✅ Error happens if Lombok is not working
            existingFoodItem.setDescription(foodDetails.getDescription());
            existingFoodItem.setPrice(foodDetails.getPrice());
            return foodRepository.save(existingFoodItem);
        }
        return null;
    }

    public void deleteFoodItem(int id) {
        foodRepository.deleteById(id);
    }
}
